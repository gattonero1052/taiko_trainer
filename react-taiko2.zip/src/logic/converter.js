import {Tab} from './tab'
import text from '../test/zc'

class Converter {
    constructor(...settings){
        this.settings = settings
    }

    convertTextToTabs(text){
        let tabs = Tab.fromText(text)
        return tabs
    }
}
