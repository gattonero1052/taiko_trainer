/**
 * TJA file loader
 *
 * @data tja file text content
 * @return
 *     measures: measures in the note
 *     startConfig: config when music starts (config can be changed halfway)
 *
 * What's in a TJA file
 * 1. configs before start
 * 2. configs after start, measures(bars) after start
 * 3. elements in the measures
 *
 * What are these configs?
 * http://taikotime.blogspot.com/2011/09/taikojiro-tutorial-how-to-make-basic.html
 *
 * What are the measures(bars)?
 * https://en.wikipedia.org/wiki/Bar_(music)
 *
 * What are these elements and their types?
 *  0=no notes
 *  1=don
 *  2=kat
 *  3=large don
 *  4=large kat
 *  5=drumroll
 *  6=large drumroll
 *  7=balloon note
 *  8=drumroll/balloon ends
 */
export const getElementByType = (type) =>{
    const map = {
        '|':{
            name: 'element-spliter',
            size: 8
        },
        '1':{
            name:'element-don',
            size:8
        },
        '2':{
            name:'element-kat',
            size:8
        },
        '3':{
            name:'element-don-big',
            size:10
        },
        '4':{
            name:'element-kat-big',
            size:10
        },
        '5':{
            name:'element-drumroll',
            size:10
        },
        '6':{
            name:'element-drumroll-large',
            size:10
        },
        '7':{
            name:'element-ballon',
            size:8
        },
    }

    return map[type] || {}
}