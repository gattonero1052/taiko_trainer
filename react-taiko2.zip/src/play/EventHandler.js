class DoubleLinkedNode{
    constructor(val,prev = null,next = null){
        this.prev = prev
        this.val = val
        this.next = next
    }
}

class DoubleLinkedDeque{
    constructor(){
        this.head = new DoubleLinkedNode(null)
        this.tail = this.head
        this.size = 0
    }

    popnode(node){
        if(this.size){
            node.prev.next = node.next
            node.next.prev = node.prev
            node.next = null
            node.prev = null
            this.size--
        }
    }

    popback(){
        if (this.size){
            let res = this.tail
            this.tail.prev.next = null
            this.tail = this.tail.prev
            this.size--
            this.front = this.head.next
            return res
        }
        return null
    }

    pushback(v){
        let node = new DoubleLinkedNode(v,this.tail,null)
        this.tail.next = node
        this.tail = node
        this.size++
        this.front = this.head.next
        v.dqNode = node
        return node
    }

    pushfront(v){
        let node = new DoubleLinkedNode(v,this.head,this.head.next)
        this.head.next.prev = node
        this.head.next = node
        this.size++
        this.front = this.head.next
        v.dqNode = node
        return node
    }

    popfront(){
        if(this.size){
            let res = this.head.next
            this.head.next = res.next
            this.head.next.prev = this.head
            this.front = this.head.next
            return res
        }
        return null
    }
}

class _Publisher{
    constructor(){
        if (!_Publisher.instance){
            this.listeners = new DoubleLinkedDeque()
        }
        _Publisher.instance = this
    }

    register(obj){
        this.listeners.pushback(obj)
    }

    unregister(obj){
        this.listeners.popnode(obj.dqNode)
    }

    publish(e){
        let cur = this.listeners.front
        let breaked = 0
        while (cur){
            if(cur.val && cur.val.listen instanceof Function){
                let res = cur.val.listen(e,breaked)
                if (res.break){
                    breaked = 1
                }
            }
        }
    }
}

const Publisher = new _Publisher()

Object.freeze(Publisher)

export {Publisher}