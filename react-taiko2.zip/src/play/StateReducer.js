import {DEFAULT_SETTING} from "../setting/setting";

const KEY = DEFAULT_SETTING.KEYBOARD

class _Reducer{
    constructor(){
        if (!_Reducer.instance){
            this.reducers = {}
            _Reducer.instance = this
        }
        return _Reducer.instance
    }

    registerAll(actions){
        const actionMap = {}
        for(let action in actions){
            let UUID = Symbol()
            actionMap[action] = UUID


            this.register({action:UUID, reducer:actions[action]})
        }
        return actionMap
    }

    register({action, reducer}){
        if (!this.reducers[action]){
            this.reducers[action] = reducer
        }
    }

    reduce({action, gameState, app}){
        let [newState, shouldUpdate] = this.reducers[action].call(null, {gameState,app})
        return [{...gameState, ...newState}, shouldUpdate]
    }

    updateState({action, gameState, app}, setGameState){
        let [newState, shouldUpdate] = this.reduce({action,gameState, app})
        if (shouldUpdate){
            return setGameState(newState)
        }
    }
}

const keyReducer = ({event, prevState})=>{
    const newState = {}
    switch(event.code){
        case KEY.d:newState.d = 1;break
        case KEY.f:newState.f = 1;break
        case KEY.j:newState.j = 1;break
        case KEY.k:newState.k = 1;break
    }

    return [{...prevState, ...newState}, 1]
}

const Reducer = new _Reducer()

Object.freeze(Reducer)

const NOTE_DRUM_BORDER = {x:0,y:252,w:300,h:210}
const NOTE_DRUM = {x:40,y:248,w:200,h:210}
const NOTE_TARGET = {x:450,y:343,r:64,r2:43}
const NOTE_TARGET_TEXT = {x:NOTE_TARGET.x,y:260,bounce:10}
const NOTE_FLY_END = {x:1780,y:80}
const NOTE_BLAST = {x:NOTE_TARGET.x,y:NOTE_TARGET.y,height:250,width:250}
const NOTE_BLAST_CENTER = {x:NOTE_TARGET.x,y:NOTE_TARGET.y,height:200,width:200}
const NOTE_TRACK = {x:0,y:252,h:210}
const NOTE_TRACK_BOTTOM = {x:0,y:418,h:44}
const NOTE_TRACK_BOTTOM_INFO = {x:0,y:462,h:100}
const SCORE_BOARD_LEFT = {x:841, y:68,h:42}
const SCORE_BOARD_RIGHT = {x:1517, y:38,w:290}

const STATIC_TEXT = {
    pass:{x:1445,y:25},
    soul:{x:1720,y:3},
    difficulty:{anchor:{x:1},x:1845,y:472}
}


const Default_GameState = {
    width:0,
    height:0,

    events:{
        click:0,
        keydown:[...Array(128)].fill(0),
    },

    elements:{

    },

    gameStarted:0,
    startTime:0,
    startMeasure:0,

    d:0,
    f:0,
    j:0,
    k:0,
    hitAnimation:0,
    drum_d:0,
    drum_f:0,
    drum_j:0,
    drum_k:0,
    dimensions:{
        STATIC_TEXT,NOTE_DRUM_BORDER,NOTE_DRUM,NOTE_TARGET,NOTE_TARGET_TEXT,
        NOTE_FLY_END,NOTE_BLAST,NOTE_BLAST_CENTER,NOTE_TRACK,NOTE_TRACK_BOTTOM,
        NOTE_TRACK_BOTTOM_INFO,SCORE_BOARD_LEFT,SCORE_BOARD_RIGHT
    }
}



export {Default_GameState, Reducer, keyReducer}