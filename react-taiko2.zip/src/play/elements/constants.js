import {Default_GameState} from "../StateReducer";
const d = Default_GameState.dimensions

const STATIC_TEXT_STYLE = {
    hit_good:{
        fontFamily: 'TnT',
        fill: ['#ffff00', '#ff4900'],
        fontSize:50,
        stroke: '#000000',
        strokeThickness:10,
    },
    hit_ok:{
        fontFamily: 'TnT',
        fill: ['#ffffff'],
        fontSize:50,
        stroke: '#000000',
        strokeThickness:10,
    },
    hit_bad:{
        fontFamily: 'TnT',
        fill: ['#5262e4', '#ffaede'],
        fontSize:50,
        stroke: '#000000',
        strokeThickness:10,
    },
    note:{
        fontFamily: 'TnT',
        fill: ['#ffffff'],
        fontSize:d.NOTE_TRACK_BOTTOM.h-20,
        stroke: '#000000',
        strokeThickness:4,
    },

    difficulty:{
        fontFamily: 'qnyy',
        fill: ['#ffffff'],
        fontSize:55
    },

    pass:{
        fontFamily: 'qnyy',
        fontWeight: 'bold',
        stroke: '#000000',
        strokeThickness:4,
        fill: ['#ffffff'],
        fontSize:40,
        dropShadow: true,
        dropShadowColor: '#000000',
        dropShadowBlur: 4,
        dropShadowAngle: Math.PI / 6,
        dropShadowDistance: 10,
    },
    soul:{
        fontFamily: 'fzkt',
        fontWeight: 'bold',
        stroke: '#000000',
        strokeThickness:15,
        fill: ['#ffffff'],fontSize:100,
        dropShadow: true,
        dropShadowColor: '#000000',
        dropShadowBlur: 4,
        dropShadowAngle: Math.PI / 6,
        dropShadowDistance: 10,
    }
}
const MOVING_TEXT = {
    DON:'DON',
    KA:'KA'
}

export {STATIC_TEXT_STYLE, MOVING_TEXT}