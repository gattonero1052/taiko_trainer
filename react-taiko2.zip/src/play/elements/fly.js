const getQuadratic = (p1, p2, p3) => {
    let arr = [p1, p2, p3].map(p => [p.x ** 2, p.x, 1, p.y])

    let var_num = 3

    //Gaussian elimination
    for (let i = 1; i < var_num; i++) {
        for (let j = i; j < var_num; j++) {
            arr[j] = arr[j].map((e, k) => e - arr[i - 1][k] * arr[j][i - 1] / arr[i - 1][i - 1])
        }
    }

    for (let i = 0; i < var_num; i++) {
        arr[i] = arr[i].map((e, j) => e / arr[i][i])
    }

    let res = arr.map(e => e[var_num])

    for (let i = var_num - 1; i > -1; i--) {
        for (let j = 0; j < var_num - 1 - i; j++) {
            res[i] -= arr[i][var_num - 1 - j] * res[var_num - 1 - j]
        }
    }

    return res//[a,b,c]
}

// bijective continuous functions in [0,1] -> [0,1]
const SpeedModel = {
    fly(x){
        return 2*x - x*x
    }
}

const pointEq = (p1, p2)=>{
    return p1.x === p2.x && p1.y === p2.y
}

class NoteFlyAnimation{
    constructor({start, end, duration}){
        this.build({start, end})
        this.duration = duration
    }

    build({start, end}){
        this.start = start
        this.end = end
        this.formula = getQuadratic(start, end, {x:end.x - (end.x-start.x)/5, y:end.y + (end.y-start.y)/5})
    }

    get({start, end, time}){
        time = Math.min(time,this.duration)

        if(!pointEq(start, this.start) || !pointEq(end, this.end)){
            this.build({start, end})
        }
        let [a,b,c] = this.formula
        let x = SpeedModel.fly(time/this.duration) * (this.end.x - this.start.x) + this.start.x
        let y = a*a*x + b*x+ c
        return {x,y}
    }
}



export {}