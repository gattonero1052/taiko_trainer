import Note1 from "./note1";
import Spliter from "./spliter";
import {AppConsumer, Container, Sprite,useTick,useApp, Text} from "@inlet/react-pixi/animated";
import React,{useState,Component,useEffect,useRef} from 'react'
import * as PIXI from "pixi.js";
import note1_1 from "../../assets/img/note1-1.png";
import Test from './testele'
import {getTextureIndex, getNoteX,getGame} from "../util";

const Note = ({code, props})=>{
    switch(code){
        case '|':return < Note1 {...props}/>
        case '1':return <Note1 {...props}/>
        default:return <Note1 {...props}/>
    }
}

const Measure = ({tab, index})=>{
    const measure = tab.measures[index]
    const app = useApp()
    const {gameState} = getGame(app)

    let [x,setX] = useState([])
    let [textures,setTextures] = useState(0)

    useTick(delta=>{
        setX(measure.notes.map(note=>getNoteX(gameState,note,app)))
        // setTextures(measure.notes.map(note=>getTextureIndex(gameState,note,app)))
    })

            {/*<Note code={note.code} props={{note, x:x[i], texture:textures[i]}}/>*/}
    return <>
        {
            measure.notes.map((note,i)=>
                <Test code={note.code} x={x[i]}/>
            )
        }
    </>
}


export default Measure
