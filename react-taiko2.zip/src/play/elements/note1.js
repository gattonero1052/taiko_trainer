import {Component,PureComponent,useEffect,useState } from 'react'
import * as PIXI from "pixi.js";
import React from 'react';
import {Text, Sprite, withPixiApp} from '@inlet/react-pixi/animated';
import {GlowFilter} from "@pixi/filter-glow";
import {AdjustmentFilter} from "@pixi/filter-adjustment";
import {Publisher} from "../EventHandler";
import {getGame, getNoteX} from "../util";
import note1_1 from "../../assets/img/note1-1.png";
import note1_2 from "../../assets/img/note1-2.png";
import {STATIC_TEXT_STYLE, MOVING_TEXT} from "./constants";

const glowFilter = new GlowFilter({distance: 4, outerStrength: 1, color: 0x000000})
const textures = [new PIXI.Texture(new PIXI.Texture.from(note1_1)), new PIXI.Texture(new PIXI.Texture.from(note1_2))]
const textStyle = new PIXI.TextStyle({...STATIC_TEXT_STYLE.note})

class Note1 extends Component{
    tickerEvents = null

    state = {
        texturesIndex : 0,
    }
    constructor(props){
        super(props)
        Publisher.register(this)
        const {gameState} = getGame(this.props.app)
        const d = gameState.dimensions
        this.state.note= {y:d.NOTE_TARGET.y}
        this.state.text = {y:d.NOTE_TRACK_BOTTOM.y + d.NOTE_TRACK_BOTTOM.h/2}
    }

    setTexture(){
        const {gameState,tab} = getGame(this.props.app)
        let index = (this.props.app.ticker.lastTime - gameState.startTime)/(tab.config.tpm*1000)*tab.config.measure_a
        this.setTexture()
    }

    // textures[this.state.textureIndex]
    render() {
        return (<>
            <Sprite visible={1} anchor={.5}
                          // filters={[glowFilter]}
                          {...this.state.note}
                            x={this.props.x||0}
                          texture={textures[0]}/>
            <Sprite visible={this.props.texture==1} anchor={.5}
                    // filters={[glowFilter]}
                    {...this.state.note}
                    x={this.props.x||0}
                    texture={textures[1]}/>
            {/*<Text text={MOVING_TEXT.DON} anchor={.5} {...this.state.text} x={this.props.x} style={textStyle}/>*/}
            </>)
    }
}
export default withPixiApp(Note1)