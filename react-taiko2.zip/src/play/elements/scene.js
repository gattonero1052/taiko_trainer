import {Sprite, Container, Text, useApp, withPixiApp ,useTick} from "@inlet/react-pixi/animated";
import note1_1 from '../../assets/img/note1-1.png'
import React, {useEffect,useState,useMemo} from 'react'
import * as PIXI from "pixi.js";
import Track from './track'
import {Default_GameState} from "../StateReducer";
import Measure from "./measure";
import {getGame} from "../util";

const texture = new PIXI.Texture(new PIXI.Texture.from(note1_1))
const MAX_MEASURE = 5

const Scene = ()=>{
    const app = useApp()
    const {gameState, tab} = getGame(app)


    const [startMeasure, setStartMeasure] = useState(0)
    const avgTimePerMeasure = tab?Math.floor(tab.duration*1000/tab.measures.length):1


    const [x,setx] = useState(0)
    useTick(delta=>
        setx(x+delta*app.ticker.deltaMS)
    )

    // useTick(delta=>{
    //     let currentMeasure = Math.floor((app.ticker.lastTime - gameState.startTime)/(avgTimePerMeasure))
    //     if (startMeasure === -1 || currentMeasure - startMeasure > MAX_MEASURE/2){
    //         setStartMeasure(Math.max(0, currentMeasure - 1))
    //     }
    // })

    let measureIndices = [...Array(tab?tab.measures.length:0).keys()].
    filter(e=>e>=startMeasure && e<startMeasure + MAX_MEASURE)
    let noteSum = measureIndices.reduce((p,c)=>p+tab.measures[c].notes.length,0)
        //rerender the static elements only when resize happens
        return (<Container>
                {useMemo(()=><Text text={JSON.stringify(app.ticker.FPS)}/>,[Math.floor(x/300)])}
                {useMemo(()=><Track/>,[gameState.width,gameState.height])}

                {measureIndices.map(index=>
                    <Measure key={'measure_'+index} gameState={gameState} tab={tab} index={index}/>
                )}
        </Container>)
}

// export default withPixiApp(Scene)
export default Scene