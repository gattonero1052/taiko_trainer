import {Sprite, Container, Text, useApp, withPixiApp ,useTick} from "@inlet/react-pixi/animated";
import note1_1 from '../../assets/img/note1-1.png'
import React, {useEffect,useState,useMemo} from 'react'
import * as PIXI from "pixi.js";
import Track from './track'
import {Default_GameState} from "../StateReducer";
import Measure from "./measure";
import {getGame, getNoteX} from "../util";
import {GlowFilter} from "@pixi/filter-glow";

const glowFilter = new GlowFilter({distance: 4, outerStrength: 1, color: 0x000000})
const texture = new PIXI.Texture(new PIXI.Texture.from(note1_1))
const MAX_MEASURE = 3

const Scene = ()=>{
    const app = useApp()
    const {gameState, tab} = getGame(app)
    const [startMeasure, setStartMeasure] = useState(0)

    const [x,setx] = useState(0)

    useTick(delta=> {
        let currentTime = app.ticker.lastTime - gameState.startTime
        if (!tab) return
        const  firstMeasure = tab.measures[startMeasure]
        if(!firstMeasure)
            return//TODO GAME END
        const  firstNotes = firstMeasure.notes
        if ((firstNotes[firstNotes.length-1].startTime + firstMeasure.startTime + 2)*1000<currentTime){
            setStartMeasure(startMeasure + 1)
        }

        setx(x + delta * app.ticker.deltaMS)
    })

    const notes = tab?tab.measures.slice(startMeasure,startMeasure + MAX_MEASURE).reduce((p,c)=>p.concat(c.notes),[]):[]

    //rerender the static elements only when resize happens
    return (<Container>
        {useMemo(()=><Text text={JSON.stringify(app.ticker.FPS)}/>,[Math.floor(x/300)])}
        {useMemo(()=><Track/>,[gameState.width,gameState.height])}

        {
            notes.map(note=>
                <Sprite
                    filters={[glowFilter]}
                    key={'note_'+(note.startTime+note.measure.startTime)+'_'+note.code} anchor={.5} texture={texture} y={gameState.dimensions.NOTE_TARGET.y} x={getNoteX(gameState,note,app)}/>
            )
        }

    </Container>)
}

// export default withPixiApp(Scene)
export default Scene