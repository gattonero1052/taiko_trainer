import {Graphics, Sprite, Container, Text, useApp, withPixiApp ,useTick} from "@inlet/react-pixi/animated";
import note1_1 from '../../assets/img/note1-1.png'
import React, {useEffect,useState,useMemo} from 'react'
import * as PIXI from "pixi.js";
import Track from './track'
import {Default_GameState} from "../StateReducer";
import {getGame, getNoteX} from "../util";
import nextState from "../handlers/all";

const Scene = ()=>{
    const app = useApp()
    const {gameState, tab} = getGame(app)
    const [startMeasure, setStartMeasure] = useState(0)

    const [x,setx] = useState(0)

    useTick(delta=> {
        nextState(app)
        setx(x + delta * app.ticker.deltaMS)
    })

    let allSprites = [], allTexts = [], allGraphics = []

    for(let p in gameState.elements){
        allSprites = allSprites.concat(gameState.elements[p].sprites || [])
        allTexts = allTexts.concat(gameState.elements[p].texts || [])
        allGraphics = allGraphics.concat(gameState.elements[p].graphics || [])
    }

    //rerender the static elements only when resize happens
    return (<Container>
        {useMemo(()=><Text text={JSON.stringify(app.ticker.FPS)}/>,[Math.floor(x/300)])}
        {useMemo(()=><Track/>,[gameState.width,gameState.height])}
        {allSprites.map(e=><Sprite {...e.props}/>)}
        {allTexts.map(e=><Text {...e.props}/>)}
        {allGraphics.map(e=><Graphics {...e.props}/>)}
    </Container>)
}

// export default withPixiApp(Scene)
export default Scene