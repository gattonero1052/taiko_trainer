import {Component,PureComponent,useEffect,useState } from 'react'
import * as PIXI from "pixi.js";
import note1_1 from "../../assets/img/note1-1.png";
import note1_2 from "../../assets/img/note1-1.png";
import React from 'react';
import {Text, Sprite} from '@inlet/react-pixi/animated';
import {GlowFilter} from "@pixi/filter-glow";
import {AdjustmentFilter} from "@pixi/filter-adjustment";

const Spliter = ()=>{}
export default Spliter