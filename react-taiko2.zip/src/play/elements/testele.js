import * as PIXI from "pixi.js";
import note1_1 from "../../assets/img/note1-1.png";
import {Component,useState} from 'react'
import {Text, Sprite, withPixiApp, useTick} from '@inlet/react-pixi/animated';

const texture = new PIXI.Texture(new PIXI.Texture.from(note1_1))

const T = ({x})=>{
    let [y,setY] = useState(100)
    // useTick(()=>{
    //     setX(x)
    // })

    return (
        <Sprite visible={1} anchor={.5}
                x={x}
                y={y}
                texture={texture}/>
    )
}

class TT extends Component{
    state = {
        y:100
    }

    constructor(prop){
        super(prop)
    }

    render(){
        return (
            <Sprite visible={1} anchor={.5}
                    x={this.props.x||0}
                    y={this.state.y}
                    texture={texture}/>
        )
    }
}

export default withPixiApp(TT)