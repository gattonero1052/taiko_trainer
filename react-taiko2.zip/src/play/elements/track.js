import {Component, PureComponent, useEffect, useState} from 'react'
import * as PIXI from "pixi.js";
import note1_1 from "../../assets/img/note1-1.png";
import note1_2 from "../../assets/img/note1-1.png";
import React from 'react';
import {Text, Sprite, Graphics, useApp} from '@inlet/react-pixi/animated';
import {GlowFilter} from "@pixi/filter-glow";
import {AdjustmentFilter} from "@pixi/filter-adjustment";
import {getGame, drawRectBorder} from "../util";

const Track = () => {
    const app = useApp()
    const {gameState} = getGame(app)

    let d = gameState.dimensions
    return (<Graphics draw={(g) => {
        g.beginFill(0x2c2a2c)
        g.drawRect(d.NOTE_TRACK.x, d.NOTE_TRACK.y, gameState.width, d.NOTE_TRACK.h)
        g.endFill()

        //bottom
        g.beginFill(0x847f84)
        g.drawRect(d.NOTE_TRACK_BOTTOM.x, d.NOTE_TRACK_BOTTOM.y, gameState.width, d.NOTE_TRACK_BOTTOM.h)
        g.endFill()

        //bottom info
        g.beginFill(0x141414)
        g.lineStyle(4,0x141414,1)
        g.drawRect(d.NOTE_TRACK_BOTTOM_INFO.x, d.NOTE_TRACK_BOTTOM_INFO.y, gameState.width, d.NOTE_TRACK_BOTTOM_INFO.h)
        g.endFill()

        drawRectBorder({g,...d.NOTE_TRACK,w:gameState.width,lineStyle:[9,0x000000,1]})

        //target
        g.lineStyle(4, 0x626262, 1)
        g.beginFill(0x2c2a2c)
        g.drawCircle(d.NOTE_TARGET.x, d.NOTE_TARGET.y, d.NOTE_TARGET.r)
        g.drawCircle(d.NOTE_TARGET.x, d.NOTE_TARGET.y, d.NOTE_TARGET.r2)
        g.endFill()
    }}/>)
}
export default Track