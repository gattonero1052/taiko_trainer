import nextNoteState from "./note";

export default function nextState(app){
    nextNoteState(app)
}