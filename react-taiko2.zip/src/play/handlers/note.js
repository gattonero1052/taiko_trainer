import {getGame, getNoteX} from "../util";
import * as PIXI from "pixi.js";
import note1_1 from "../../assets/img/note1-1.png";
import {GlowFilter} from "@pixi/filter-glow";
import {STATIC_TEXT_STYLE} from "../elements/constants";

const MAX_MEASURE = 3

const textures = {
    don1:new PIXI.Texture(new PIXI.Texture.from(note1_1))
}

const getTexture = (code, index)=>{
    // switch(code){
    //     case '|':return null
    //     case '1':
    //         return textures.don1
    // }
    return textures.don1
}

const getText = (code)=>{
    // switch(code){
    //     case '|':return ''
    //     case '1':return 'DON'
    // }
    return 'DON'
}

const textStyle = new PIXI.TextStyle({...STATIC_TEXT_STYLE.note})
const glowFilter = new GlowFilter({distance: 4, outerStrength: 1, color: 0x000000})

const nextState = (app)=>{
    const {gameState, tab,time} = getGame(app)

    const  firstMeasure = tab.measures[gameState.startMeasure]

    if(!firstMeasure)
        return//TODO GAME END

    const  firstNotes = firstMeasure.notes
    if ((firstNotes[firstNotes.length-1].startTime + firstMeasure.startTime + 2)*1000<time){
        gameState.startMeasure += 1
    }

    const notes = tab?tab.measures.slice(gameState.startMeasure,gameState.startMeasure + MAX_MEASURE).reduce((p,c)=>p.concat(c.notes),[]):[]

    if(!gameState.elements.notes)
        gameState.elements.notes = {}

    if(!gameState.elements.notes.sprites)
        gameState.elements.notes.sprites = []

    if(!gameState.elements.notes.texts)
        gameState.elements.notes.texts = []

    let psprites = gameState.elements.notes.sprites
    let ptexts = gameState.elements.notes.texts

    while (psprites.length && notes && psprites[0].id!=notes[0].id){
        psprites.splice(0,1)
        ptexts.splice(0,1)
    }

    while (notes && psprites.length<notes.length){
        psprites.push({id:notes[psprites.length].id,props:{}})
        ptexts.push({id:notes[ptexts.length].id,props:{}})
    }

    //set properties
    notes.forEach((note,i)=>{
        let text = ptexts[i]
        let sprite = psprites[i]
        text.props.key = sprite.props.key = note.id
        text.props.text = getText(note.code)
        text.props.style = textStyle
        text.props.anchor = sprite.props.anchor = .5
        text.props.x = sprite.props.x = getNoteX(gameState,note,app)
        text.props.y = gameState.dimensions.NOTE_TRACK_BOTTOM.y + gameState.dimensions.NOTE_TRACK_BOTTOM.h / 2
        sprite.props.y = gameState.dimensions.NOTE_TARGET.y
        sprite.props.texture = getTexture(note.code)
        sprite.props.filters = [glowFilter]
    })
}

export default nextState