import React, {Component, useState, useEffect} from 'react'
import * as PIXI from "pixi.js";
import Scene from './elements/scene3'
import {Tab} from '../logic/tab'
import text from '../test/zc'
import {Default_GameState, Reducer} from "./StateReducer";
import './index.css'
import {Stage, AppConsumer, Text, Container} from "@inlet/react-pixi/animated";

//Register all actions connected to this component in the beginning
const action = Reducer.registerAll({
    GameStart({gameState, app}){
        app.ticker.start()
        app.view.focus()
        return [{gameStarted:1, startTime:app.ticker.lastTime},1]
    },

    Resize({gameState, app}){
       return [{width:window.innerWidth, height:window.innerHeight},1]
    },
})

//Here reason not using hook
//state need to include update state function itself to pass to the context
//https://en.reactjs.org/docs/context.html#updating-context-from-a-nested-component
class Play extends Component{
    app = null

    constructor(props){
        super(props)

        this.setGameState = (newState) =>{
            this.setState(({
                gameState:newState
            }))
        }

        this.state = {
            tab:null,
            gameState:Default_GameState,
            setGameState:this.setGameState
        }
    }

    componentDidMount() {
        let tabs = Tab.fromText(text)
        this.setState({tab:tabs[0]})
    }

    keyEventHandler(e){
        this.state.gameState.events.keydown[e.keyCode] = 1
        this.setGameState(this.state.gameState)
    }

    render() {
        //put state in app as app is the global context (can't find a way to wrap another context top of it)
        if(this.app)
            this.app.state = this.state

            return (<><Stage
                    onMount={app=>{
                        this.app = app
                        app.ticker.stop()
                        app.view.setAttribute('tabIndex',1)
                        app.view.addEventListener('keydown', this.keyEventHandler.bind(this))
                        Reducer.updateState({action:action.Resize, gameState:this.state.gameState}, this.setGameState.bind(this))
                    }}

                    width={window.innerWidth} height={window.innerHeight}
                    options={{
                        antialias:true,
                        backgroundColor: 0x10bb99,
                        autoResize: true,
                        resizeTo:window,
                        resolution: devicePixelRatio,
                    }}>
                    <Scene/>
                </Stage>

            <div className="play_mask" tabIndex={0} onClick={() => {
                this.app.ticker.start()
                console.log('ticker started')
                this.app.view.focus()
                this.setGameState({...this.state.gameState, gameStarted:1, startTime:this.app.ticker.lastTime})
            }}

                 style={{display: this.state.gameState.gameStarted == 0 ? 'flex' : 'none'}}>
                <div style={{fontFamily: 'TnT', fontSize: 100}}>PLAY</div>
                <div style={{fontFamily: ' fzkt', fontSize: 100, opacity: 0}}>1</div>
                <div style={{fontFamily: ' qnyy', fontSize: 100, opacity: 0}}>1</div>
            </div> </>)
    }
}

// {/*<Text text={JSON.stringify(v.gameState)}/>*/}

// const Scene1 = ()=>{
//     return (<Consumer>{((v)=><Stage
//
//         width={window.innerWidth} height={window.innerHeight}
//         options={{
//             backgroundColor: 0x10bb99,
//             autoResize: true,
//             resizeTo:window,
//             resolution: devicePixelRatio,
//         }}
//
//     ><Text text={JSON.stringify(v.gameState)}/></Stage>)}</Consumer>)
// }

// const Play = () => {
//     const [gameState, setGameState] = useState(Default_GameState)
//     const [tab, setTab] = useState(null)
//     const v = {gameState, setGameState}
//
//     const keyEventHandler = ()=>{
//
//     }
//
//     console.log('index:'+gameState.gameStarted)
//
//     useEffect(() => {
//         let tabs = Tab.fromText(text)
//         setTab(tabs[0])
//     }, [])
//
//     return (
//         <Provider value={v}>
//             <Stage
//                 onMount={app=>{
//                     app.ticker.stop()
//                     app.view.setAttribute('tabIndex',1)
//                     app.view.addEventListener('keydown', keyEventHandler)
//                 }}
//
//                 width={window.innerWidth} height={window.innerHeight}
//                    options={{
//                     backgroundColor: 0x10bb99,
//                     autoResize: true,
//                     resizeTo:window,
//                     resolution: devicePixelRatio,
//             }}>
//                 <Scene tab={tab} gameState={gameState}/>
//             </Stage>
//
//             <div className="play_mask" tabIndex={0} onClick={() => Reducer.updateState({action:action.GameStart, gameState}, setGameState)}
//                  style={{display: gameState.gameStarted == 0 ? 'flex' : 'none'}}>
//                 <div style={{fontFamily: 'TnT', fontSize: 100}}>PLAY</div>
//                 <div style={{fontFamily: ' fzkt', fontSize: 100, opacity: 0}}>1</div>
//                 <div style={{fontFamily: ' qnyy', fontSize: 100, opacity: 0}}>1</div>
//             </div>
//         </Provider>
//     )
// }

export default Play

// const G = ()=>{
//     const [s,cs] = useState({a:1,b:2})
//     console.log('X')
//     return (<>
//         <button onClick={()=>{
//             cs({...s})
//         }}>do not change anthing</button>
//     </>)
//     // return (<Stage options={{backgroundColor:0x10bb99,autoResize:true,resizeTo:window}}></Stage>)
// }
// export default G

// const GC = React.createContext(null)
// class G extends Component{
//     constructor(props){
//         super(props)
//         this.state = {
//             a:1,
//             b:2,
//             c:[3]
//         }
//
//         this.app = {
//             a:1,
//             b:2,
//             c:[3]
//         }
//     }
//
//     render() {
//         return (
//             <>
//             <button onClick={()=>this.setState({a:this.state.a+1})}>button</button>
//             <GC.Provider value={this.state}>
//                 <GC.Consumer>{v=><div>{JSON.stringify(v)}</div>}</GC.Consumer>
//         </GC.Provider></>)
//     }
// }
//
// export default G