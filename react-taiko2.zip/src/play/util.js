import {Default_GameState} from "./StateReducer";

export function getGame(app){
    const gameState = app.state?app.state.gameState:Default_GameState
    const tab = app.state?app.state.tab:null
    const time = app.ticker.lastTime - gameState.startTime
    return {gameState, tab,time}
}

export function drawRectBorder({g,x,y,w,h,lineStyle}, mode = 0){//0: inner, 1: outer, 2:middle
    let d2 = mode === 0 ?Math.floor(lineStyle[0]/2):
        mode === 1? -Math.floor(lineStyle[0]/2):
            mode === 2? 0:
                0;

    g.lineStyle(...lineStyle)
    g.moveTo(x+d2,y+d2)
    g.lineTo(x+w-d2,y+d2)
    g.lineTo(x+w-d2,y+h-d2)
    g.lineTo(x+d2,y+h-d2)
    g.closePath()
}

export function getNoteX (gameState,note,app){
    if (!gameState || ! note || !app) return 0

    return gameState.dimensions.NOTE_TARGET.x +
        (app.state.tab.config.measureOffset + note.startTime + note.measure.startTime -
            (app.ticker.lastTime - gameState.startTime) / 1000) *
        note.measure.state.scroll * 1000
}

export function getTextureIndex (gameState,note,app){
    return Math.floor((app.ticker.lastTime - note.measure.startTime*1000) / (note.measure.tpb*1000)) & 1
}