import React, {useRef, useEffect} from 'react'
import * as PIXI from "pixi.js";
import note1_1 from "../assets/img/note1-1.png";
import Stats from "stats.js";
import {GlowFilter} from "@pixi/filter-glow";
const texture = new PIXI.Texture(new PIXI.Texture.from(note1_1))

let sprites = [], renderer = null, app = null
const spritesCount = 100
const glowFilter = new GlowFilter({distance: 6, outerStrength: 1, color: 0x000000})

const Raw = ()=>{
    const canvas = useRef()

    useEffect(()=>{
        app = new PIXI.Application({
            width: window.innerWidth, height: window.innerHeight, backgroundColor: 0x1099bb, resolution: window.devicePixelRatio || 1,
            view:canvas.current
        });

        // renderer = PIXI.autoDetectRenderer(800, 600, {backgroundColor:0xFFFFFF});
        // stage = new PIXI.Stage(0xFFFFFF);
        // renderer.context.mozImageSmoothingEnabled = false
        // renderer.context.webkitImageSmoothingEnabled = false;

        sprites = [...Array(spritesCount).keys()].map(e=> {
            let sprite = new PIXI.Sprite(texture)
            sprite.x = window.innerWidth/2
            sprite.y = window.innerHeight/2
            sprite.anchor.set(0.5)
            app.stage.addChild(sprite)
            sprite.filters = [glowFilter]
            return sprite
        })

        app.ticker.add(()=>{
            sprites.forEach((sprite, index)=>{
                sprite.position.x += Math.cos(Math.PI*2/100*index) * 0.3
                sprite.position.y += Math.sin(Math.PI*2/100*index) * 0.3
            })
        })

        const stats = new Stats();
        stats.showPanel( 0 ); // 0: fps, 1: ms, 2: mb, 3+: custom
        document.body.appendChild( stats.dom );

        app.ticker.add(()=>{
            stats.begin();
            stats.end();
        })
    },[])

    // useTick((delta)=>{
    //     sprites.forEach((sprite,index)=> {
    //         sprite.position.x += Math.cos(Math.PI*2/100*index)*5
    //         sprite.position.y += Math.sin(Math.PI*2/100*index)*5
    //     })
    // })

    return (<canvas ref={canvas}></canvas>)
}

export default Raw