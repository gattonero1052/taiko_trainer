const DEFAULT_SETTING = {
    KEYBOARD:{'d':'KeyD','f':'KeyF','j':'KeyJ','k':'KeyK'},
    JUDGE:{'good':50/2,'ok':150/2,'bad':217/2}
}

const MOVING_TEXT = {
    DON:'DON',
    KA:'KA'
}

export {DEFAULT_SETTING, MOVING_TEXT}